﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MID_PROJECT_B_DB_2022R2021_CS_214
{
    public partial class ManageRubrics : UserControl
    {
        public ManageRubrics()
        {
            InitializeComponent();
            displayRubric();
            moveButtons();
        }

        private void moveButtons()
        {
            rubricTableData.Columns["Edit"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            rubricTableData.Columns["Delete"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            rubricTableData.Columns["Level"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            rubricTableData.Columns["Level"].DisplayIndex = rubricTableData.Columns.Count - 1;
            rubricTableData.Columns["Edit"].DisplayIndex = rubricTableData.Columns.Count - 1;
            rubricTableData.Columns["Delete"].DisplayIndex = rubricTableData.Columns.Count - 1;
        }

        private void ManageRubrics_Load(object sender, EventArgs e)
        {
            loadData();
        }

        private void ManageRubrics_Click(object sender, EventArgs e)
        {
            loadData();
        }

        public void loadData()
        {

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select Name,Id From Clo", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbxCLO.DataSource = dt;
            cmbxCLO.DisplayMember = "Name";
            cmbxCLO.ValueMember = "Id";
        }

        private int get_id()
        {
            int nextId = 1; // Default value if no records exist
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT MAX(ID) FROM Rubric", con);
            object result = cmd.ExecuteScalar();
            if (result != null && int.TryParse(result.ToString(), out int maxId))
            {
                nextId = maxId + 1;
            }
            return nextId;
        }

        private int getCLOId(string CLO)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT Id FROM Clo WHERE Name=@Name", con);
            cmd.Parameters.AddWithValue("@Name", CLO);
            object data = cmd.ExecuteScalar();
            Int32 result = (Int32)data;
            cmd.ExecuteNonQuery();
            return result;
        }
        private void displayRubric()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT R.*,C.Name as [CLO Name] FROM Rubric R JOIN Clo C ON R.CloId=C.Id", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable d = new DataTable();
            da.Fill(d);
            rubricTableData.DataSource = d;
            rubricTableData.AllowUserToAddRows = false;
            rubricTableData.Columns["Id"].Visible = false;
            rubricTableData.Columns["CloId"].Visible = false;
        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            if (txtRubricDetail.Text != "")
            {
                int CLOId = getCLOId(cmbxCLO.Text);
                int Id = get_id();
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert Into Rubric values(@Id,@Details,@CloId)", con);
                cmd.Parameters.AddWithValue("@Details", txtRubricDetail.Text);
                cmd.Parameters.AddWithValue("@CloId", int.Parse(cmbxCLO.SelectedValue.ToString()));
                cmd.Parameters.AddWithValue("@Id", Id);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Added Succesfully");
                txtRubricDetail.ResetText();
                displayRubric();
            }
            else
            {
                MessageBox.Show("Please enter all required fields !!!");
            }
        }

        private void rubricTableData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            if (rubricTableData.Columns["Delete"].Index == e.ColumnIndex)
            {
                if (DialogResult.Yes == MessageBox.Show("Do You Want Delete ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
                {
                    SqlCommand cmd = new SqlCommand("Delete From Rubric Where Id=@Id", con);
                    int selectedrowindex = rubricTableData.SelectedCells[0].RowIndex;
                    DataGridViewRow selectedRow = rubricTableData.Rows[selectedrowindex];
                    string cellValue = Convert.ToString(selectedRow.Cells["Id"].Value);
                    int id = int.Parse(cellValue);
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.ExecuteNonQuery();
                    displayRubric();


                }
            }
            if (rubricTableData.Columns["Edit"].Index == e.ColumnIndex)
            {
                DataGridViewRow row = this.rubricTableData.Rows[e.RowIndex];
                string Details = row.Cells["Details"].Value.ToString();
                string CloId = row.Cells["CloId"].Value.ToString();
                string Id = row.Cells["Id"].Value.ToString();

                EditRubrics E = new EditRubrics(Details, CloId, Id);
                E.ShowDialog();
                displayRubric();

            }
            if (rubricTableData.Columns["Level"].Index == e.ColumnIndex)
            {
                DataGridViewRow row = this.rubricTableData.Rows[e.RowIndex];
                string Details = row.Cells["Details"].Value.ToString();
                string CloId = row.Cells["CloId"].Value.ToString();
                string CloName = row.Cells["CLO Name"].Value.ToString();
                string Id = row.Cells["Id"].Value.ToString();
                RubricLevel R = new RubricLevel(CloName, CloId, Details, Id);
                R.ShowDialog();

            }
        }
    }
}
