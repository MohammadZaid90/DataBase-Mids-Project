﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MID_PROJECT_B_DB_2022R2021_CS_214
{
    public partial class AddStudent : Form
    {
        public AddStudent()
        {
            InitializeComponent();
        }

        private int checkingIfRegistrationNumberExist()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT Id FROM Student WHERE RegistrationNumber='" + txtRegNo.Text + "'", con);
            int cnt = Convert.ToInt32(cmd.ExecuteScalar());
            return cnt;
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private bool IsValidRegistrationNo(string regNo)
        {
            string pattern = @"\d{4}-[A-Za-z]{2}-\d{1,3}";
            return Regex.IsMatch(regNo, pattern);
        }

        private bool IsValidContact(string contact)
        {
            return contact.Length == 11 && contact.StartsWith("03");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtRegNo.Text) || string.IsNullOrWhiteSpace(txtFName.Text) || string.IsNullOrWhiteSpace(txtSName.Text) || string.IsNullOrWhiteSpace(txtContact.Text) || string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Please fill in all required fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!IsValidEmail(txtEmail.Text))
            {
                MessageBox.Show("Please enter a valid email address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!IsValidContact(txtContact.Text))
            {
                MessageBox.Show("Contact number must start with '03' and be 11 characters long.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!IsValidRegistrationNo(txtRegNo.Text))
            {
                MessageBox.Show("Invalid registration number format. Example format: 'XXXX-CS-X'.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int res = checkingIfRegistrationNumberExist();

            if (res == 0)
            {
                try
                {


                    int status = 5;
                    if (UnactiveRadio.Checked == true)
                    {
                        status = 6;
                    }
                    var con = Configuration.getInstance().getConnection();
                    SqlCommand cmd = new SqlCommand("Insert Into Student values(@FirstName,@LastName,@Contact,@Email,@RegistrationNumber,@Status)", con);
                    cmd.Parameters.AddWithValue("@RegistrationNumber", txtRegNo.Text);
                    cmd.Parameters.AddWithValue("@FirstName", txtFName.Text);
                    cmd.Parameters.AddWithValue("@LastName", txtSName.Text);
                    cmd.Parameters.AddWithValue("@Contact", txtContact.Text);
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@Status", status);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Student Added Succesfully");
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while adding the student: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Error Registration Number Already Exist");
            }
        }
    }
}
