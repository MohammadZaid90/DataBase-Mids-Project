﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace MID_PROJECT_B_DB_2022R2021_CS_214
{
    public partial class EditClo : Form
    {
        int idn;
        public EditClo(string name, string ID)
        {
            InitializeComponent();
            txtName.Text = name;
            idn = int.Parse(ID);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtName.Text != "")
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("UPDATE Clo SET Name=@Name,DateUpdated=@DateUpdated Where Id=@Id", con);
                cmd.Parameters.AddWithValue("@Name", txtName.Text);
                cmd.Parameters.AddWithValue("@Id", idn);
                cmd.Parameters.AddWithValue("@DateUpdated", dateTimeCLO.Value);
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Updated Succesfully");
                this.Close();
            }
            else
            {
                MessageBox.Show("Please enter all required fields !!!");
            }
        }
    }
}
