﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MID_PROJECT_B_DB_2022R2021_CS_214
{
    public partial class FrontPage : UserControl
    {
        public FrontPage()
        {
            InitializeComponent();
        }
    }
}
