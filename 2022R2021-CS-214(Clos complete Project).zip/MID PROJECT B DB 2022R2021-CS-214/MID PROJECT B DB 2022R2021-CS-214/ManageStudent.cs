﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MID_PROJECT_B_DB_2022R2021_CS_214
{
    public partial class ManageStudent : UserControl
    {
        public ManageStudent()
        {
            InitializeComponent();
            displayStudent();
            moveButtons();
        }
        private void moveButtons()
        {
            studentTableData.Columns["Edit"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            studentTableData.Columns["Delete"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            studentTableData.Columns["Edit"].DisplayIndex = studentTableData.Columns.Count - 1;
            studentTableData.Columns["Delete"].DisplayIndex = studentTableData.Columns.Count - 1;


        }
        private void displayStudent()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT S.Id,S.RegistrationNumber,S.FirstName,S.LastName,S.Contact,S.Email,L.Name as [Status]\r\nFROM STUDENT S\r\nJOIN Lookup L\r\nON S.Status=L.LookupId;", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable d = new DataTable();
            da.Fill(d);
            studentTableData.DataSource = d;
            studentTableData.AllowUserToAddRows = false;
            studentTableData.Columns["Id"].Visible = false;

        }

        private void studentTableData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            if (studentTableData.Columns["Delete"].Index == e.ColumnIndex)
            {
                if (DialogResult.Yes == MessageBox.Show("Do You Want Delete ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
                {
                    // Delete associated records from StudentResult table first
                    SqlCommand deleteResultCmd = new SqlCommand("DELETE FROM StudentResult WHERE StudentId=@StudentId", con);
                    int selectedrowindex = studentTableData.SelectedCells[0].RowIndex;
                    DataGridViewRow selectedRow = studentTableData.Rows[selectedrowindex];
                    string studentId = Convert.ToString(selectedRow.Cells["Id"].Value);
                    deleteResultCmd.Parameters.AddWithValue("@StudentId", studentId);
                    deleteResultCmd.ExecuteNonQuery();

                    // Now delete the student from the Student table
                    SqlCommand deleteStudentCmd = new SqlCommand("DELETE FROM Student WHERE RegistrationNumber=@RegistrationNumber", con);
                    string registrationNumber = Convert.ToString(selectedRow.Cells["RegistrationNumber"].Value);
                    deleteStudentCmd.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);
                    deleteStudentCmd.ExecuteNonQuery();

                    // Refresh the student data grid view
                    displayStudent();
                }
            }
            if (studentTableData.Columns["Edit"].Index == e.ColumnIndex)
            {
                DataGridViewRow row = this.studentTableData.Rows[e.RowIndex];
                string RegNo = row.Cells["RegistrationNumber"].Value.ToString();
                string FName = row.Cells["FirstName"].Value.ToString();
                string LName = row.Cells["LastName"].Value.ToString();
                string Contact = row.Cells["Contact"].Value.ToString();
                string Email = row.Cells["Email"].Value.ToString();
                string Status = row.Cells["Status"].Value.ToString();
                string Id = row.Cells["Id"].Value.ToString();
                if (Status == "Active")
                {
                    Status = "5";
                }
                else
                {
                    Status = "6";
                }
                EditStudent E = new EditStudent(RegNo, FName, LName, Contact, Email, Status, Id);
                E.ShowDialog();
                displayStudent();
            }
        }

        private void btnAddNewStudent_Click(object sender, EventArgs e)
        {
            AddStudent S = new AddStudent();
            S.ShowDialog();
            displayStudent();
        }
    }
}
