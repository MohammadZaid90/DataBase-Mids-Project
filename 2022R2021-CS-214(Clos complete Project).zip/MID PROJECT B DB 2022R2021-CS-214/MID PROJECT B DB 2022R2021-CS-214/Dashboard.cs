﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MID_PROJECT_B_DB_2022R2021_CS_214
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
            frontPage1.Show();
            frontPage1.BringToFront();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            frontPage1.Hide();
            manageStudent1.Hide();
            manageAttendence1.Hide();
            manageRubrics1.Hide();
            manageClo1.Hide();
            manageAssessment1.Hide();
            manageComponents1.Hide();
            manageEvaluation1.Hide();
            managePDFReport1.Hide();
            homePage1.Show();
            homePage1.setText();
            homePage1.BringToFront();
        }

        private void btnStudent_Click(object sender, EventArgs e)
        {
            frontPage1.Hide();
            homePage1.Hide();
            manageAttendence1.Hide();
            manageAssessment1.Hide();
            manageClo1.Hide();
            manageRubrics1.Hide();
            manageComponents1.Hide();
            manageEvaluation1.Hide();
            managePDFReport1.Hide();
            manageStudent1.Show();
            manageStudent1.BringToFront();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            homePage1.Hide();
            manageStudent1.Hide();
            manageAttendence1.Hide();
            manageAssessment1.Hide();
            manageClo1.Hide();
            manageRubrics1.Hide();
            manageComponents1.Hide();
            manageEvaluation1.Hide();
            managePDFReport1.Hide();
            frontPage1.Show();
            frontPage1.BringToFront();
        }
        private void btnAttendance_Click(object sender, EventArgs e)
        {
            frontPage1.Hide();
            homePage1.Hide();
            manageStudent1.Hide();
            manageAssessment1.Hide();
            manageClo1.Hide();
            manageRubrics1.Hide();
            manageComponents1.Hide();
            manageEvaluation1.Hide();
            managePDFReport1.Hide();
            manageAttendence1.Show();
            manageAttendence1.BringToFront();
        }

        private void btnCLO_Click(object sender, EventArgs e)
        {
            frontPage1.Hide();
            homePage1.Hide();
            manageStudent1.Hide();
            manageAssessment1.Hide();
            manageAttendence1.Hide();
            manageRubrics1.Hide();
            manageComponents1.Hide();
            manageEvaluation1.Hide();
            managePDFReport1.Hide();
            manageClo1.Show();
            manageClo1.BringToFront();
        }

        private void btnRubric_Click(object sender, EventArgs e)
        {
            frontPage1.Hide();
            homePage1.Hide();
            manageStudent1.Hide();
            manageAttendence1.Hide();
            manageAssessment1.Hide();
            manageClo1.Hide();
            manageComponents1.Hide();
            manageEvaluation1.Hide();
            managePDFReport1.Hide();
            manageRubrics1.Show();
            manageRubrics1.BringToFront();
            manageRubrics1.loadData();
        }

        private void btnAssessment_Click(object sender, EventArgs e)
        {
            frontPage1.Hide();
            homePage1.Hide();
            manageStudent1.Hide();
            manageAttendence1.Hide();
            manageClo1.Hide();
            manageRubrics1.Hide();
            manageComponents1.Hide();
            manageEvaluation1.Hide();
            managePDFReport1.Hide();
            manageAssessment1.Show();
            manageAssessment1 .BringToFront();
        }

        private void btnAssessmentComponent_Click(object sender, EventArgs e)
        {
            frontPage1.Hide();
            homePage1.Hide();
            manageStudent1.Hide();
            manageAttendence1.Hide();
            manageClo1.Hide();
            manageRubrics1.Hide();
            manageAssessment1.Hide();
            manageEvaluation1.Hide();
            managePDFReport1.Hide();
            manageComponents1.loadComboxes();
            manageComponents1.Show();
            manageComponents1 .BringToFront();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMarkEvaluation_Click(object sender, EventArgs e)
        {
            frontPage1.Hide();
            homePage1.Hide();
            manageStudent1.Hide();
            manageAttendence1.Hide();
            manageClo1.Hide();
            manageRubrics1.Hide();
            manageAssessment1.Hide();
            manageComponents1.Hide();
            managePDFReport1.Hide();
            manageEvaluation1.loadComboBoxes();
            manageEvaluation1.Show();
            manageEvaluation1.BringToFront();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            frontPage1.Hide();
            homePage1.Hide();
            manageStudent1.Hide();
            manageAttendence1.Hide();
            manageClo1.Hide();
            manageRubrics1.Hide();
            manageAssessment1.Hide();
            manageComponents1.Hide();
            manageEvaluation1.Hide();
            managePDFReport1.Show();
            managePDFReport1 .BringToFront();
        }
    }
}
