﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace MID_PROJECT_B_DB_2022R2021_CS_214
{
    public partial class EditStudent : Form
    {
        int id = -1;
        public EditStudent(string reg, string FName, string LName, string Contact, string Email, string status, string Id)
        {
            InitializeComponent();
            txtRegNo.Text = reg;
            txtFName.Text = FName;
            txtSName.Text = LName;
            txtContact.Text = Contact;
            txtEmail.Text = Email;
            id = int.Parse(Id);
            if (int.Parse(status) == 5)
            {
                ActiveRadio.Checked = true;
            }
            else
            {
                UnactiveRadio.Checked = true;
            }
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private bool IsValidRegistrationNo(string regNo)
        {
            string pattern = @"\d{4}-[A-Za-z]{2}-\d{1,3}";
            return Regex.IsMatch(regNo, pattern);
        }

        private bool IsValidContact(string contact)
        {
            return contact.Length == 11 && contact.StartsWith("03");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtRegNo.Text) || string.IsNullOrWhiteSpace(txtFName.Text) || string.IsNullOrWhiteSpace(txtSName.Text) || string.IsNullOrWhiteSpace(txtContact.Text) || string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Please fill in all required fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!IsValidEmail(txtEmail.Text))
            {
                MessageBox.Show("Please enter a valid email address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!IsValidContact(txtContact.Text))
            {
                MessageBox.Show("Contact number must start with '03' and be 11 characters long.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!IsValidRegistrationNo(txtRegNo.Text))
            {
                MessageBox.Show("Invalid registration number format. Example format: 'XXXX-CS-X'.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int status = 5;
            if (UnactiveRadio.Checked)
            {
                status = 6;
            }

            try
            {
                var con = Configuration.getInstance().getConnection();
                using (SqlCommand cmd = new SqlCommand("UPDATE Student SET FirstName=@FirstName,LastName=@LastName,Contact=@Contact,Email=@Email,Status=@Status,RegistrationNumber=@RegistrationNumber WHERE Id=@Id", con))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Parameters.AddWithValue("@RegistrationNumber", txtRegNo.Text);
                    cmd.Parameters.AddWithValue("@FirstName", txtFName.Text);
                    cmd.Parameters.AddWithValue("@LastName", txtSName.Text);
                    cmd.Parameters.AddWithValue("@Contact", txtContact.Text);
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@Status", status);

                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Student Updated Successfully");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while updating the student: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
