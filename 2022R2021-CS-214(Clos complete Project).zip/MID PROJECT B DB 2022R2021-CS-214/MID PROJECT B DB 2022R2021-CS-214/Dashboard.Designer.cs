﻿namespace MID_PROJECT_B_DB_2022R2021_CS_214
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnCLO = new System.Windows.Forms.Button();
            this.btnStudent = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.btnAttendance = new System.Windows.Forms.Button();
            this.btnRubric = new System.Windows.Forms.Button();
            this.btnAssessment = new System.Windows.Forms.Button();
            this.btnAssessmentComponent = new System.Windows.Forms.Button();
            this.btnMarkEvaluation = new System.Windows.Forms.Button();
            this.btnReport = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.frontPage2 = new MID_PROJECT_B_DB_2022R2021_CS_214.FrontPage();
            this.managePDFReport1 = new MID_PROJECT_B_DB_2022R2021_CS_214.ManagePDFReport();
            this.manageEvaluation1 = new MID_PROJECT_B_DB_2022R2021_CS_214.ManageEvaluation();
            this.manageComponents1 = new MID_PROJECT_B_DB_2022R2021_CS_214.ManageComponents();
            this.manageAssessment1 = new MID_PROJECT_B_DB_2022R2021_CS_214.ManageAssessment();
            this.manageRubrics1 = new MID_PROJECT_B_DB_2022R2021_CS_214.ManageRubrics();
            this.manageClo1 = new MID_PROJECT_B_DB_2022R2021_CS_214.ManageClo();
            this.manageAttendence1 = new MID_PROJECT_B_DB_2022R2021_CS_214.ManageAttendence();
            this.manageStudent1 = new MID_PROJECT_B_DB_2022R2021_CS_214.ManageStudent();
            this.homePage1 = new MID_PROJECT_B_DB_2022R2021_CS_214.HomePage();
            this.frontPage1 = new MID_PROJECT_B_DB_2022R2021_CS_214.FrontPage();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Gold;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 27);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 841F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(329, 841);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.Gold;
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.button1, 0, 10);
            this.tableLayoutPanel3.Controls.Add(this.btnCLO, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.btnStudent, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.btnHome, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.btnAttendance, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.btnRubric, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.btnAssessment, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.btnAssessmentComponent, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.btnMarkEvaluation, 0, 8);
            this.tableLayoutPanel3.Controls.Add(this.btnReport, 0, 9);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox1, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 50);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(3, 50, 3, 20);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 11;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 96F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.954059F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.035222F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.49464F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.341501F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.9589F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.076682F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.859155F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.17214F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.79812F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.64163F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(323, 771);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Image = global::MID_PROJECT_B_DB_2022R2021_CS_214.Properties.Resources.icons8_back_50;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(3, 697);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 3, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(317, 72);
            this.button1.TabIndex = 38;
            this.button1.Text = "  CLOSE";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnCLO
            // 
            this.btnCLO.BackColor = System.Drawing.Color.Gold;
            this.btnCLO.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCLO.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCLO.FlatAppearance.BorderSize = 0;
            this.btnCLO.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCLO.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCLO.ForeColor = System.Drawing.Color.Black;
            this.btnCLO.Image = global::MID_PROJECT_B_DB_2022R2021_CS_214.Properties.Resources.icons8_content_48;
            this.btnCLO.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCLO.Location = new System.Drawing.Point(3, 291);
            this.btnCLO.Margin = new System.Windows.Forms.Padding(3, 3, 3, 5);
            this.btnCLO.Name = "btnCLO";
            this.btnCLO.Size = new System.Drawing.Size(317, 55);
            this.btnCLO.TabIndex = 25;
            this.btnCLO.Text = "  CLOs";
            this.btnCLO.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnCLO.UseVisualStyleBackColor = false;
            this.btnCLO.Click += new System.EventHandler(this.btnCLO_Click);
            // 
            // btnStudent
            // 
            this.btnStudent.BackColor = System.Drawing.Color.Gold;
            this.btnStudent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStudent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStudent.FlatAppearance.BorderSize = 0;
            this.btnStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStudent.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStudent.ForeColor = System.Drawing.Color.Black;
            this.btnStudent.Image = global::MID_PROJECT_B_DB_2022R2021_CS_214.Properties.Resources.icons8_student_48;
            this.btnStudent.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStudent.Location = new System.Drawing.Point(3, 166);
            this.btnStudent.Margin = new System.Windows.Forms.Padding(3, 3, 3, 2);
            this.btnStudent.Name = "btnStudent";
            this.btnStudent.Size = new System.Drawing.Size(317, 56);
            this.btnStudent.TabIndex = 24;
            this.btnStudent.Text = "  STUDENTS";
            this.btnStudent.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnStudent.UseVisualStyleBackColor = false;
            this.btnStudent.Click += new System.EventHandler(this.btnStudent_Click);
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.Color.Gold;
            this.btnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.Black;
            this.btnHome.Image = global::MID_PROJECT_B_DB_2022R2021_CS_214.Properties.Resources.icons8_home_48;
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.Location = new System.Drawing.Point(3, 99);
            this.btnHome.Margin = new System.Windows.Forms.Padding(3, 3, 3, 2);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(317, 62);
            this.btnHome.TabIndex = 23;
            this.btnHome.Text = "  HOME";
            this.btnHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // btnAttendance
            // 
            this.btnAttendance.BackColor = System.Drawing.Color.Gold;
            this.btnAttendance.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAttendance.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAttendance.FlatAppearance.BorderSize = 0;
            this.btnAttendance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAttendance.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAttendance.ForeColor = System.Drawing.Color.Black;
            this.btnAttendance.Image = global::MID_PROJECT_B_DB_2022R2021_CS_214.Properties.Resources.icons8_attendance_48;
            this.btnAttendance.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAttendance.Location = new System.Drawing.Point(3, 227);
            this.btnAttendance.Margin = new System.Windows.Forms.Padding(3, 3, 3, 2);
            this.btnAttendance.Name = "btnAttendance";
            this.btnAttendance.Size = new System.Drawing.Size(317, 59);
            this.btnAttendance.TabIndex = 32;
            this.btnAttendance.Text = "  ATTENDENCE";
            this.btnAttendance.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAttendance.UseVisualStyleBackColor = false;
            this.btnAttendance.Click += new System.EventHandler(this.btnAttendance_Click);
            // 
            // btnRubric
            // 
            this.btnRubric.BackColor = System.Drawing.Color.Gold;
            this.btnRubric.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRubric.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRubric.FlatAppearance.BorderSize = 0;
            this.btnRubric.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRubric.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRubric.ForeColor = System.Drawing.Color.Black;
            this.btnRubric.Image = global::MID_PROJECT_B_DB_2022R2021_CS_214.Properties.Resources.icons8_abacus_49;
            this.btnRubric.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRubric.Location = new System.Drawing.Point(3, 354);
            this.btnRubric.Margin = new System.Windows.Forms.Padding(3, 3, 3, 2);
            this.btnRubric.Name = "btnRubric";
            this.btnRubric.Size = new System.Drawing.Size(317, 69);
            this.btnRubric.TabIndex = 34;
            this.btnRubric.Text = "  RUBRICS";
            this.btnRubric.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRubric.UseVisualStyleBackColor = false;
            this.btnRubric.Click += new System.EventHandler(this.btnRubric_Click);
            // 
            // btnAssessment
            // 
            this.btnAssessment.BackColor = System.Drawing.Color.Gold;
            this.btnAssessment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAssessment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAssessment.FlatAppearance.BorderSize = 0;
            this.btnAssessment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAssessment.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssessment.ForeColor = System.Drawing.Color.Black;
            this.btnAssessment.Image = global::MID_PROJECT_B_DB_2022R2021_CS_214.Properties.Resources.icons8_assessment_48;
            this.btnAssessment.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAssessment.Location = new System.Drawing.Point(3, 428);
            this.btnAssessment.Margin = new System.Windows.Forms.Padding(3, 3, 3, 2);
            this.btnAssessment.Name = "btnAssessment";
            this.btnAssessment.Size = new System.Drawing.Size(317, 56);
            this.btnAssessment.TabIndex = 26;
            this.btnAssessment.Text = "  ASSESSMENTS";
            this.btnAssessment.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAssessment.UseVisualStyleBackColor = false;
            this.btnAssessment.Click += new System.EventHandler(this.btnAssessment_Click);
            // 
            // btnAssessmentComponent
            // 
            this.btnAssessmentComponent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAssessmentComponent.FlatAppearance.BorderSize = 0;
            this.btnAssessmentComponent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAssessmentComponent.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold);
            this.btnAssessmentComponent.ForeColor = System.Drawing.Color.Black;
            this.btnAssessmentComponent.Image = global::MID_PROJECT_B_DB_2022R2021_CS_214.Properties.Resources.icons8_view_details_48;
            this.btnAssessmentComponent.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAssessmentComponent.Location = new System.Drawing.Point(3, 489);
            this.btnAssessmentComponent.Margin = new System.Windows.Forms.Padding(3, 3, 3, 2);
            this.btnAssessmentComponent.Name = "btnAssessmentComponent";
            this.btnAssessmentComponent.Size = new System.Drawing.Size(317, 61);
            this.btnAssessmentComponent.TabIndex = 35;
            this.btnAssessmentComponent.Text = "  COMPONENTS";
            this.btnAssessmentComponent.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnAssessmentComponent.UseVisualStyleBackColor = true;
            this.btnAssessmentComponent.Click += new System.EventHandler(this.btnAssessmentComponent_Click);
            // 
            // btnMarkEvaluation
            // 
            this.btnMarkEvaluation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMarkEvaluation.FlatAppearance.BorderSize = 0;
            this.btnMarkEvaluation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMarkEvaluation.Font = new System.Drawing.Font("Century Gothic", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMarkEvaluation.ForeColor = System.Drawing.Color.Black;
            this.btnMarkEvaluation.Image = global::MID_PROJECT_B_DB_2022R2021_CS_214.Properties.Resources.icons8_evaluation_48;
            this.btnMarkEvaluation.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMarkEvaluation.Location = new System.Drawing.Point(3, 555);
            this.btnMarkEvaluation.Margin = new System.Windows.Forms.Padding(3, 3, 3, 2);
            this.btnMarkEvaluation.Name = "btnMarkEvaluation";
            this.btnMarkEvaluation.Size = new System.Drawing.Size(317, 64);
            this.btnMarkEvaluation.TabIndex = 31;
            this.btnMarkEvaluation.Text = "  MARK EVALUATION";
            this.btnMarkEvaluation.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMarkEvaluation.UseVisualStyleBackColor = true;
            this.btnMarkEvaluation.Click += new System.EventHandler(this.btnMarkEvaluation_Click);
            // 
            // btnReport
            // 
            this.btnReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnReport.FlatAppearance.BorderSize = 0;
            this.btnReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReport.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport.ForeColor = System.Drawing.Color.Black;
            this.btnReport.Image = global::MID_PROJECT_B_DB_2022R2021_CS_214.Properties.Resources.icons8_pdf_48;
            this.btnReport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReport.Location = new System.Drawing.Point(3, 624);
            this.btnReport.Margin = new System.Windows.Forms.Padding(3, 3, 3, 2);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(317, 68);
            this.btnReport.TabIndex = 36;
            this.btnReport.Text = "  PDF REPORTS";
            this.btnReport.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnReport.UseVisualStyleBackColor = true;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox1.Image = global::MID_PROJECT_B_DB_2022R2021_CS_214.Properties.Resources.icons8_computer_database_96;
            this.pictureBox1.Location = new System.Drawing.Point(109, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(104, 87);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 37;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.frontPage2);
            this.panel1.Controls.Add(this.managePDFReport1);
            this.panel1.Controls.Add(this.manageEvaluation1);
            this.panel1.Controls.Add(this.manageComponents1);
            this.panel1.Controls.Add(this.manageAssessment1);
            this.panel1.Controls.Add(this.manageRubrics1);
            this.panel1.Controls.Add(this.manageClo1);
            this.panel1.Controls.Add(this.manageAttendence1);
            this.panel1.Controls.Add(this.manageStudent1);
            this.panel1.Controls.Add(this.homePage1);
            this.panel1.Controls.Add(this.frontPage1);
            this.panel1.Location = new System.Drawing.Point(329, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(832, 842);
            this.panel1.TabIndex = 2;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.SlateGray;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 304F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(329, 28);
            this.tableLayoutPanel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.SlateGray;
            this.label1.Font = new System.Drawing.Font("Wide Latin", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(274, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "DASHBOARD";
            // 
            // frontPage2
            // 
            this.frontPage2.Location = new System.Drawing.Point(0, 0);
            this.frontPage2.Name = "frontPage2";
            this.frontPage2.Size = new System.Drawing.Size(837, 740);
            this.frontPage2.TabIndex = 9;
            // 
            // managePDFReport1
            // 
            this.managePDFReport1.Location = new System.Drawing.Point(0, 3);
            this.managePDFReport1.Name = "managePDFReport1";
            this.managePDFReport1.Size = new System.Drawing.Size(832, 807);
            this.managePDFReport1.TabIndex = 8;
            // 
            // manageEvaluation1
            // 
            this.manageEvaluation1.Location = new System.Drawing.Point(-3, 1);
            this.manageEvaluation1.Name = "manageEvaluation1";
            this.manageEvaluation1.Size = new System.Drawing.Size(832, 842);
            this.manageEvaluation1.TabIndex = 7;
            // 
            // manageComponents1
            // 
            this.manageComponents1.Location = new System.Drawing.Point(0, 0);
            this.manageComponents1.Name = "manageComponents1";
            this.manageComponents1.Size = new System.Drawing.Size(832, 833);
            this.manageComponents1.TabIndex = 6;
            // 
            // manageAssessment1
            // 
            this.manageAssessment1.Location = new System.Drawing.Point(0, 3);
            this.manageAssessment1.Name = "manageAssessment1";
            this.manageAssessment1.Size = new System.Drawing.Size(829, 830);
            this.manageAssessment1.TabIndex = 5;
            // 
            // manageRubrics1
            // 
            this.manageRubrics1.Location = new System.Drawing.Point(0, 1);
            this.manageRubrics1.Name = "manageRubrics1";
            this.manageRubrics1.Size = new System.Drawing.Size(829, 847);
            this.manageRubrics1.TabIndex = 4;
            // 
            // manageClo1
            // 
            this.manageClo1.Location = new System.Drawing.Point(0, 0);
            this.manageClo1.Name = "manageClo1";
            this.manageClo1.Size = new System.Drawing.Size(829, 839);
            this.manageClo1.TabIndex = 3;
            // 
            // manageAttendence1
            // 
            this.manageAttendence1.Location = new System.Drawing.Point(3, 3);
            this.manageAttendence1.Name = "manageAttendence1";
            this.manageAttendence1.Size = new System.Drawing.Size(829, 830);
            this.manageAttendence1.TabIndex = 2;
            // 
            // manageStudent1
            // 
            this.manageStudent1.Location = new System.Drawing.Point(6, 12);
            this.manageStudent1.Name = "manageStudent1";
            this.manageStudent1.Size = new System.Drawing.Size(823, 827);
            this.manageStudent1.TabIndex = 1;
            // 
            // homePage1
            // 
            this.homePage1.Location = new System.Drawing.Point(3, 12);
            this.homePage1.Name = "homePage1";
            this.homePage1.Size = new System.Drawing.Size(826, 823);
            this.homePage1.TabIndex = 0;
            // 
            // frontPage1
            // 
            this.frontPage1.Location = new System.Drawing.Point(6, 12);
            this.frontPage1.Name = "frontPage1";
            this.frontPage1.Size = new System.Drawing.Size(817, 821);
            this.frontPage1.TabIndex = 0;
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 855);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnCLO;
        private System.Windows.Forms.Button btnStudent;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button btnAttendance;
        private System.Windows.Forms.Button btnRubric;
        private System.Windows.Forms.Button btnAssessment;
        private System.Windows.Forms.Button btnAssessmentComponent;
        private System.Windows.Forms.Button btnMarkEvaluation;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private FrontPage frontPage1;
        private HomePage homePage1;
        private ManageStudent manageStudent1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private ManageAttendence manageAttendence1;
        private ManageClo manageClo1;
        private ManageRubrics manageRubrics1;
        private ManageAssessment manageAssessment1;
        private ManageComponents manageComponents1;
        private ManageEvaluation manageEvaluation1;
        private ManagePDFReport managePDFReport1;
        private FrontPage frontPage2;
    }
}

